# Rockstar Games Launcher APK

## Description
Application Android qui redirige automatiquement vers rockstargames.com dans le navigateur par défaut.

## Structure du projet
```
RockstarApp/
├── app/
│   ├── src/main/
│   │   ├── java/com/rockstar/launcher/
│   │   │   └── MainActivity.kt        ← Code principal
│   │   ├── res/
│   │   │   ├── drawable/              ← Logo Rockstar (vecteur)
│   │   │   ├── mipmap-*/             ← Icônes app
│   │   │   └── values/               ← Thème + strings
│   │   └── AndroidManifest.xml
│   └── build.gradle
├── build.gradle
├── settings.gradle
└── .gitignore
```

## Comment construire l'APK

### Méthode 1 : Android Studio (recommandé)
1. Ouvre Android Studio
2. File > Open > sélectionne le dossier `RockstarApp`
3. Attends la synchronisation Gradle
4. Build > Build Bundle(s) / APK(s) > Build APK(s)
5. L'APK sera dans `app/build/outputs/apk/debug/`

### Méthode 2 : Ligne de commande
```bash
cd RockstarApp
chmod +x gradlew
./gradlew assembleDebug
# APK → app/build/outputs/apk/debug/app-debug.apk
```

## Fonctionnement
- L'utilisateur clique sur l'icône de l'app
- L'app s'ouvre (fond orange Rockstar)
- Redirige immédiatement vers https://www.rockstargames.com
- L'app se ferme (noHistory=true)
