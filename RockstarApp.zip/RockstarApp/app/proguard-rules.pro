# Rockstar Launcher - No obfuscation needed
-keep class com.rockstar.launcher.** { *; }
